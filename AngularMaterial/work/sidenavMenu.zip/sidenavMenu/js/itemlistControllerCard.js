
angular.module('MyAppCard',['ngMaterial', 'ngMessages', 'material.svgAssetsCache'])
.controller('MyAppCardCtrl', function($scope, $http) {
  	$scope.imagePath = 'img/nature.jpg'

});


/**
Copyright 2016 Google Inc. All Rights Reserved. 
Use of this source code is governed by an MIT-style license that can be in foundin the LICENSE file at http://material.angularjs.org/license.
**/