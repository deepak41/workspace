var module = angular.module("sampleApp", ['ngRoute']);

module.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
                when('/items', {
                    templateUrl: 'partials/item.html',
                    controller: 'ItemCtrl'
                }).
                when('/preferences', {
                    templateUrl: 'partials/preferences.html',
                    controller: 'OrderCtrl'
                }).
                when('/settings', {
                    templateUrl: 'partials/settings.html',
                    controller: 'UserCtrl'

                }).
                when('/logout', {
                    templateUrl: 'partials/logout.html',
                    controller: 'MyAppAddUserCtrl'

                }).
                when('/shoppingcart', {
                    templateUrl: 'partials/shoppingcart.html',
                    controller: 'MyAppAddUserCtrl'

                }).
                when('/newlistitem', {
                    templateUrl: 'partials/newlistitem.html',
                    controller: 'NewListItemCtrl'

                }).
                when('/edititem', {
                    templateUrl: 'partials/edititem.html',
                    controller: 'UserCtrl'

                }).
                when('/listitem', {
                    templateUrl: 'partials/itemlist.html',
                    controller: 'gridListDemoCtrl'

                }).
                otherwise({
                    redirectTo: '/items'
                });
    }]);

module.controller('ItemCtrl', function ($scope) {
    $scope.name="This is items page"
});

module.controller('OrderCtrl', function ($scope) {
    $scope.name="This is orders page"
});

module.controller('UserCtrl', function ($scope) {
    $scope.name="This is Users page"
});