(function () {
    'use strict';
    angular
        .module('NewListItem',['ngMaterial', 'ngMessages', 'material.svgAssetsCache'])
        .controller('NewListItemCtrl', NewListItemCtrl);

    function NewListItemCtrl ($scope, $log, $http) {


        $http.get('dummydata/mock.json').success(function(response){
            var values = response;
            console.log(values[0]);

            // for filtering categories
            var tabs=[];
            for (var i=0; i<values.length; i++) {
               console.log(values[i]); 
                if (tabs.length == 0) {
                    tabs.push(values[i]);
                    continue;
                }
                for(var j=0; j<tabs.length; j++) {
                    if(values[i].category == tabs[j].category){
                        break;
                    }
                    else {
                        if(j==tabs.length-1){
                            tabs.push(values[i]);

                        }
                        else
                            continue;
                    }
                }
            }



            var selected = null,
                previous = null;
            $scope.tabs = tabs;
            $scope.selectedIndex = 2;
            $scope.$watch('selectedIndex', function(current, old){
                previous = selected;
                selected = tabs[current];
            });
            $scope.addTab = function (category, view) {
                view = view || category + " Content View";
                tabs.push({ category: category, itemDesc: view, disabled: false});
            };
            $scope.removeTab = function (tab) {
                var index = tabs.indexOf(tab);
                tabs.splice(index, 1);
            };
        });
    }
})();



/**
 Copyright 2016 Google Inc. All Rights Reserved.
 Use of this source code is governed by an MIT-style license that can be in foundin the LICENSE file at http://material.angularjs.org/license.
 **/